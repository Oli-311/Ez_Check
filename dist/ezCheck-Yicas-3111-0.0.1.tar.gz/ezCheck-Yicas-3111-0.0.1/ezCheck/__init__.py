from ezCheck.workspace import EzCheck
